# BÀI 02 - KẾT QUẢ KIỂM THỬ RUNTIME

![Kết quả chạy Test Cases](ketqua_test.png)