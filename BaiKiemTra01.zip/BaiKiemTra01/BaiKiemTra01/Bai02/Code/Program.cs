using System;

namespace LogisticsAutoSpeed
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            QuanLyPhuongTien ql = new QuanLyPhuongTien();

            // TC01: Test Validation Năm SX
            try
            {
                OTo otoLoi = new OTo("OT00", "Toyota", 1850, 1000000000m, 5, 2.0);
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"[TC 01] Lỗi: {ex.Message}");
            }

            // TC02 & TC03: Tạo Ô tô & Xe máy
            OTo oto1 = new OTo("OT01", "Toyota", 2022, 1000000000m, 5, 2.0);
            XeMay xemay1 = new XeMay("XM01", "Honda", 2023, 5000000m, 150);

            // TC04: Thêm vào danh sách & In ra (Đa hình)
            ql.AddPhuongTien(oto1);
            ql.AddPhuongTien(xemay1);
            Console.WriteLine("\n[TC 04] Danh sách phương tiện:");
            ql.DisplayAll();

            // TC05: Tìm xe có giá lăn bánh Max
            PhuongTien maxPT = ql.FindMaxGiaLanBanh();
            Console.WriteLine($"\n[TC 05] Xe có Giá lăn bánh Max: {maxPT.TenHang} - {maxPT.TinhGiaLanBanh():N0} VNĐ");
        }
    }
}