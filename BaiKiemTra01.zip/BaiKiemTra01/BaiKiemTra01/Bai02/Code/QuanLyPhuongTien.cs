using System;
using System.Collections.Generic;
using System.Linq;

namespace LogisticsAutoSpeed
{
    public class QuanLyPhuongTien
    {
        private readonly List<PhuongTien> _list = new List<PhuongTien>();

        public void AddPhuongTien(PhuongTien pt) => _list.Add(pt);

        public void DisplayAll()
        {
            foreach (var pt in _list)
                Console.WriteLine(pt.GetInfo());
        }

        public PhuongTien FindMaxGiaLanBanh()
        {
            return _list.OrderByDescending(pt => pt.TinhGiaLanBanh()).FirstOrDefault();
        }

        public List<PhuongTien> SearchByName(string keyword)
        {
            return _list.Where(pt => pt.TenHang.Contains(keyword, StringComparison.OrdinalIgnoreCase)).ToList();
        }
    }
}