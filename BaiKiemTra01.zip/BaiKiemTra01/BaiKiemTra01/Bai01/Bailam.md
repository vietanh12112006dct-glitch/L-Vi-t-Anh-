# BÀI 01: PHẦN LÝ THUYẾT & CÂU HỎI NGẮN

## Câu 1: Phân biệt Value Types và Reference Types (Stack vs Heap)
- **Value Types (Kiểu giá trị):** Lưu trữ trực tiếp giá trị thực tế trên bộ nhớ Stack. Khi gán hoặc truyền tham số, C# sao chép bản sao của giá trị. Bộ nhớ tự động giải phóng khi ra khỏi scope.
- **Reference Types (Kiểu tham chiếu):** Lưu trữ địa chỉ tham chiếu (con trỏ) trên Stack, còn đối tượng thực tế được cấp phát trên bộ nhớ Heap. Khi gán, các biến cùng trỏ về 1 địa chỉ ô nhớ. Bộ nhớ do Garbage Collector (GC) tự động quản lý.

## Câu 2: Tính năng Init-only Properties (`init`) trong C# 9/10
- Khác biệt với `set` thông thường: Thuộc tính `set` có thể thay đổi giá trị bất kỳ lúc nào. Trong khi đó, `init` chỉ cho phép gán giá trị một lần duy nhất tại thời điểm khởi tạo đối tượng (qua Constructor hoặc Object Initializer).
- **Trường hợp sử dụng:** Dùng để tạo các đối tượng bất biến (Immutable Objects), DTOs (Data Transfer Objects), giúp bảo vệ dữ liệu không bị vô tình chỉnh sửa.

## Câu 3: Phân biệt phương thức `virtual` (lớp cha) và `override` (lớp con)
- `virtual` khai báo ở lớp cha cho phép phương thức có thể được ghi đè bởi lớp con, bản thân lớp cha vẫn có thể cài đặt logic mặc định.
- `override` khai báo ở lớp con để định nghĩa lại/nạp chồng logic của phương thức từ lớp cha.
- Khi triển khai tính Đa hình (Polymorphism), Runtime C# sẽ dựa trên kiểu của đối tượng thực tế được khởi tạo để kích hoạt đúng phiên bản `override` tương ứng.

## Câu 4: Tại sao thành phần `static` không truy xuất qua thể hiện (Object Instance)?
- Thành phần `static` thuộc về cấp độ Lớp (Class level) chứ không thuộc về thể hiện/đối tượng riêng lẻ (Instance level). Nó được cấp phát vùng nhớ duy nhất khi ứng dụng khởi chạy và dùng chung cho tất cả các đối tượng.
- C# quy định không cho truy xuất `static` từ biến thể hiện tạo bởi toán tử `new` để tránh nhầm lẫn về ngữ nghĩa và tối ưu hóa bộ nhớ.