﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace LogisticsApp
{
    public partial class Form1 : Form
    {
        private List<SanPham> dsSanPham = new List<SanPham>();
        private string duongDanAnh = "";

        private TableLayoutPanel tableLayout;
        private Panel panelLeft;
        private TextBox txtMaSP, txtTenSP, txtDonGia;
        private Button btnThem, btnChonAnh, btnXoa;
        private PictureBox picBox;
        private DataGridView dgvDanhSach;
        private ErrorProvider errorProvider;

        public Form1()
        {
            InitializeComponent();
            TaoGiaoDienDep();
        }

        private void TaoGiaoDienDep()
        {
            this.Text = "Quản Lý Sản Phẩm - Logistics";
            this.Size = new Size(950, 500);

            errorProvider = new ErrorProvider();

            // TC01: Layout 35% - 65%
            tableLayout = new TableLayoutPanel();
            tableLayout.Dock = DockStyle.Fill;
            tableLayout.ColumnCount = 2;
            tableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 38F));
            tableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 62F));

            panelLeft = new Panel { Dock = DockStyle.Fill, AutoScroll = true };

            // Tọa độ chuẩn không bị đè chữ
            Label lblMa = new Label { Text = "Mã SP:", Top = 20, Left = 15, AutoSize = true };
            txtMaSP = new TextBox { Top = 17, Left = 90, Width = 220 };

            Label lblTen = new Label { Text = "Tên SP:", Top = 60, Left = 15, AutoSize = true };
            txtTenSP = new TextBox { Top = 57, Left = 90, Width = 220 };

            Label lblGia = new Label { Text = "Đơn giá:", Top = 100, Left = 15, AutoSize = true };
            txtDonGia = new TextBox { Top = 97, Left = 90, Width = 220 };

            btnChonAnh = new Button { Text = "Chọn Ảnh", Top = 140, Left = 15, Width = 90, Height = 30 };
            btnChonAnh.Click += BtnChonAnh_Click;

            // TC04: PictureBox Zoom
            picBox = new PictureBox
            {
                Top = 140,
                Left = 115,
                Width = 195,
                Height = 130,
                BorderStyle = BorderStyle.FixedSingle,
                SizeMode = PictureBoxSizeMode.Zoom
            };

            btnThem = new Button { Text = "Thêm mới", Top = 290, Left = 15, Width = 130, Height = 35 };
            btnThem.Click += BtnThem_Click;

            btnXoa = new Button { Text = "Xóa SP", Top = 290, Left = 180, Width = 130, Height = 35 };
            btnXoa.Click += BtnXoa_Click;

            panelLeft.Controls.AddRange(new Control[] {
                lblMa, txtMaSP, lblTen, txtTenSP, lblGia, txtDonGia,
                btnChonAnh, picBox, btnThem, btnXoa
            });

            // DataGridView phình to lấp đầy cột phải
            dgvDanhSach = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false
            };

            tableLayout.Controls.Add(panelLeft, 0, 0);
            tableLayout.Controls.Add(dgvDanhSach, 1, 0);

            this.Controls.Add(tableLayout);
        }

        // TC02: Validation
        private bool KiemTraHopLe()
        {
            bool hopLe = true;
            errorProvider.Clear();

            if (string.IsNullOrWhiteSpace(txtTenSP.Text))
            {
                errorProvider.SetError(txtTenSP, "Tên sản phẩm không được để trống!");
                hopLe = false;
            }

            if (!decimal.TryParse(txtDonGia.Text, out decimal donGia) || donGia <= 0)
            {
                errorProvider.SetError(txtDonGia, "Đơn giá phải lớn hơn 0!");
                hopLe = false;
            }

            return hopLe;
        }

        private void BtnThem_Click(object sender, EventArgs e)
        {
            if (!KiemTraHopLe()) return;

            dsSanPham.Add(new SanPham
            {
                MaSP = string.IsNullOrWhiteSpace(txtMaSP.Text) ? "SP01" : txtMaSP.Text,
                TenSP = txtTenSP.Text,
                DonGia = decimal.Parse(txtDonGia.Text),
                HinhAnh = duongDanAnh
            });

            CapNhatGrid();
            XoaForm();
            MessageBox.Show("Thêm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // TC03: Format tiền 25,000,000 VNĐ
        private void CapNhatGrid()
        {
            dgvDanhSach.DataSource = null;
            dgvDanhSach.DataSource = dsSanPham.Select(p => new
            {
                Mã_SP = p.MaSP,
                Tên_Sản_Phẩm = p.TenSP,
                Đơn_Giá = p.DonGia.ToString("N0") + " VNĐ",
                Hình_Ảnh = !string.IsNullOrEmpty(p.HinhAnh) ? "Đã nạp" : "Chưa có"
            }).ToList();
        }

        // TC04: OpenFileDialog
        private void BtnChonAnh_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "File Ảnh (*.png; *.jpg)|*.png;*.jpg";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    duongDanAnh = ofd.FileName;
                    picBox.Image = Image.FromFile(duongDanAnh);
                }
            }
        }

        // TC05: Popup Yes/No
        private void BtnXoa_Click(object sender, EventArgs e)
        {
            if (dgvDanhSach.CurrentRow == null)
            {
                MessageBox.Show("Vui lòng chọn 1 dòng để xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Bạn có chắc chắn muốn xóa?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int idx = dgvDanhSach.CurrentRow.Index;
                if (idx >= 0 && idx < dsSanPham.Count)
                {
                    dsSanPham.RemoveAt(idx);
                    CapNhatGrid();
                }
            }
        }

        private void XoaForm()
        {
            txtMaSP.Clear();
            txtTenSP.Clear();
            txtDonGia.Clear();
            duongDanAnh = "";
            picBox.Image = null;
            errorProvider.Clear();
        }
    }

    public class SanPham
    {
        public string MaSP { get; set; }
        public string TenSP { get; set; }
        public decimal DonGia { get; set; }
        public string HinhAnh { get; set; }
    }
}